"""Current version of package pkt_kg"""
__version__ = "3.1.2"
